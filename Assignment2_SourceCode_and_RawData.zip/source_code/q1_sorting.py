"""Q1 - Selection, Bubble and Insertion Sort under different data conditions"""
import random, time, csv
random.seed(2511054)

def selection_sort(a):
    a = a[:]; n = len(a); comp = moves = 0
    for i in range(n - 1):
        m = i
        for j in range(i + 1, n):
            comp += 1
            if a[j] < a[m]: m = j
        if m != i:
            a[i], a[m] = a[m], a[i]; moves += 1
    return a, comp, moves

def bubble_sort(a):            # with early-exit flag
    a = a[:]; n = len(a); comp = moves = 0
    for i in range(n - 1):
        swapped = False
        for j in range(n - 1 - i):
            comp += 1
            if a[j] > a[j + 1]:
                a[j], a[j + 1] = a[j + 1], a[j]; moves += 1; swapped = True
        if not swapped: break
    return a, comp, moves

def insertion_sort(a):
    a = a[:]; comp = moves = 0
    for i in range(1, len(a)):
        key = a[i]; j = i - 1
        while j >= 0:
            comp += 1
            if a[j] > key:
                a[j + 1] = a[j]; moves += 1; j -= 1
            else: break
        a[j + 1] = key
    return a, comp, moves

N = 1000
base = sorted(random.sample(range(1, 100000), N))
def nearly_sorted_95():
    old = sorted(random.sample(range(1, 100000), 950))
    new = [random.randint(1, 100000) for _ in range(50)]
    return old + new                      # 95 % in order, 5 % new orders appended
datasets = {
 "D1 Random": random.sample(range(1, 100000), N),
 "D2 Already sorted": base[:],
 "D3 Reverse sorted": base[::-1],
 "D4 95% sorted + 5% new": nearly_sorted_95(),
 "D5 All equal (edge)": [500] * N,
}
rows = []
for name, d in datasets.items():
    for alg, f in (("Selection", selection_sort), ("Bubble", bubble_sort), ("Insertion", insertion_sort)):
        t = time.perf_counter(); out, c, m = f(d); t = (time.perf_counter() - t) * 1000
        assert out == sorted(d)
        rows.append([name, alg, c, m, round(t, 3)])
with open("../data/q1_raw.csv", "w", newline="") as fh:
    w = csv.writer(fh); w.writerow(["dataset", "algorithm", "comparisons", "swaps_or_shifts", "time_ms"]); w.writerows(rows)
print(f"{'Dataset':26}{'Algorithm':11}{'Comparisons':>12}{'Moves':>10}{'Time(ms)':>10}")
for r in rows: print(f"{r[0]:26}{r[1]:11}{r[2]:>12,}{r[3]:>10,}{r[4]:>10}")
