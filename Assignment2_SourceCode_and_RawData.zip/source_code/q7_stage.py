"""Q7 - staged evidence: Stage A (incremental DFS + feasibility pruning only) vs Stage B (+ ratio ordering + bound)"""
import random, json
from q6_exhaustive import exhaustive
from q7_redesign import redesigned
def stage_a(items, cap):
    n = len(items); nodes = [0]; best = [0]
    def dfs(k, w, v):
        nodes[0] += 1
        if v > best[0]: best[0] = v
        if k == n: return
        if w + items[k][0] <= cap: dfs(k + 1, w + items[k][0], v + items[k][1])
        dfs(k + 1, w, v)
    dfs(0, 0, 0); return best[0], nodes[0]
random.seed(8); out = []
print(f"{'n':>3}{'Original 2^n':>14}{'Stage A nodes':>15}{'A reduction':>13}{'Stage B nodes':>15}{'B reduction':>13}")
for n in (10, 12, 14, 16, 18, 20, 21):
    items = [(random.randint(5, 40), random.randint(10, 100)) for _ in range(n)]
    cap = sum(w for w, _ in items) // 2
    ov = exhaustive(items, cap)[0]; av, an = stage_a(items, cap); bv, _, bn = redesigned(items, cap)
    assert ov == av == bv
    out.append([n, 2**n, an, bn]); print(f"{n:>3}{2**n:>14,}{an:>15,}{2**n/an:>13.2f}{bn:>15,}{2**n/bn:>13.1f}")
json.dump(out, open("../data/q7_stage.json", "w"))
import csv
with open("../data/q7_stage.csv","w",newline="") as f:
    w=csv.writer(f); w.writerow(["n","exhaustive_2^n","stageA_nodes","stageB_nodes"]); w.writerows(out)
