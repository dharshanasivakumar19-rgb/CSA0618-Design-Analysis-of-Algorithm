"""Q5 - Brute-force convex hull derived from the 'all points on one side' principle"""
import random, csv, json
def cross(a, b, p):                     # sign of (b-a) x (p-a)  <=> side of p relative to line a->b
    return (b[0]-a[0])*(p[1]-a[1]) - (b[1]-a[1])*(p[0]-a[0])
def on_segment(a, b, p):
    return min(a[0],b[0]) <= p[0] <= max(a[0],b[0]) and min(a[1],b[1]) <= p[1] <= max(a[1],b[1])
def brute_hull(pts):
    pts = sorted(set(pts)); n = len(pts); edges = []; tests = 0
    for i in range(n - 1):
        for j in range(i + 1, n):
            a, b = pts[i], pts[j]; pos = neg = 0; ok = True
            for k in range(n):
                if k == i or k == j: continue
                tests += 1
                c = cross(a, b, pts[k])
                if c > 0: pos += 1
                elif c < 0: neg += 1
                elif not on_segment(a, b, pts[k]): ok = False; break   # collinear but outside -> a,b not extreme
                if pos and neg: ok = False; break                       # both sides -> reject early
            if ok: edges.append((a, b) if neg == 0 else (b, a))        # orient so interior lies on the left (CCW)
    # chain edges into an ordered boundary
    if not edges: return pts, [], tests
    nxt = {}
    for a, b in edges:
        nxt.setdefault(a, []).append(b)
    if len(pts) == 2 or all(c == 0 for c in [0]): pass
    start = edges[0][0]; order = [start]; cur = nxt[start][0]
    while cur != start and len(order) <= len(edges) + 1:
        order.append(cur); cur = nxt[cur][0]
    return order, edges, tests
if __name__ == "__main__":
    random.seed(21)
    A = [(2,3),(4,9),(9,2),(12,8),(7,12),(5,6),(8,7),(6,4),(10,5),(7,8),(3,7),(9,10)]
    B = [(0,0),(4,0),(8,0),(8,4),(8,8),(4,8),(0,8),(0,4),(4,4),(2,2),(6,6),(4,0),(2,6),(6,2)]   # square + collinear boundary pts + interior + duplicate
    out = {}
    for nm, P in (("A", A), ("B", B)):
        h, e, t = brute_hull(P); out[nm] = {"pts": P, "hull": h}
        print(f"Set {nm}: {len(set(P))} distinct points, hull vertices = {len(h)}, edges accepted = {len(e)}, side tests = {t}")
        print("  hull (CCW):", h)
    rows = []; print(f"\n{'n':>5}{'pairs':>10}{'side tests':>13}{'n^3/2 approx':>14}{'hull size':>11}")
    for n in (10, 20, 40, 80, 160, 320):
        P = [(random.randint(0, 1000), random.randint(0, 1000)) for _ in range(n)]
        h, e, t = brute_hull(P); rows.append([n, n*(n-1)//2, t, len(h)])
        print(f"{n:>5}{n*(n-1)//2:>10,}{t:>13,}{n**3//2:>14,}{len(h):>11}")
    # worst case for early-rejection: all points on a circle (all are hull vertices)
    import math; rows2 = []
    print("\nWorst case (points on a circle - every point is a hull vertex):")
    for n in (10, 20, 40, 80, 160):
        P = [(round(1000000+900000*math.cos(2*math.pi*k/n)), round(1000000+900000*math.sin(2*math.pi*k/n))) for k in range(n)]
        h, e, t = brute_hull(P); rows2.append([n, t, len(h)]); print(f"n={n:>4}  side tests={t:>10,}  hull size={len(h)}  n(n-1)(n-2)/2={n*(n-1)*(n-2)//2:,}")
    with open("../data/q5_raw.csv","w",newline="") as f:
        w=csv.writer(f); w.writerow(["random_n","pairs","side_tests","hull_size"]); w.writerows(rows)
        w.writerow([]); w.writerow(["circle_n","side_tests","hull_size"]); w.writerows(rows2)
    json.dump({"sets":out,"rand":rows,"circle":rows2}, open("../data/q5_sets.json","w"))
