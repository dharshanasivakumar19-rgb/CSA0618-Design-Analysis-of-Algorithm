"""Q3 - Brute-force string matching: character-comparison counts"""
import random, csv
def brute(text, pat):
    n, m = len(text), len(pat); comp = 0; first = -1
    for i in range(n - m + 1):
        j = 0
        while j < m:
            comp += 1
            if text[j + i] != pat[j]: break
            j += 1
        if j == m and first < 0: first = i; break
    return first, comp
def brute_all(text, pat):          # scans entire text (all matches) - used for full-scan comparison
    n, m = len(text), len(pat); comp = 0; hits = 0
    for i in range(n - m + 1):
        j = 0
        while j < m:
            comp += 1
            if text[i + j] != pat[j]: break
            j += 1
        if j == m: hits += 1
    return hits, comp
random.seed(11)
n, m = 10000, 50
tests = []
t1 = ("B" * n, "A" + "B" * (m - 1))                       # first char mismatches every time
t2 = ("A" * n, "A" * (m - 1) + "B")                       # mismatch only on last char
alpha = "abcdefghijklmnopqrstuvwxyz "
t3 = ("".join(random.choice(alpha) for _ in range(n)), "failed password for root")  # realistic log-like
t4 = ("A" * n, "A" * m)                                    # match at position 0
t5 = ("".join(random.choice("AB") for _ in range(n)), "A" * 20 + "B")   # binary alphabet
print(f"{'Test':34}{'n':>7}{'m':>5}{'Comparisons':>13}{'(n-m+1)':>9}{'(n-m+1)m':>11}{'Ratio c/n':>10}")
rows = []
for name, (t, p) in [("T1 Best: first-char mismatch", t1), ("T2 Worst: last-char mismatch", t2),
                     ("T3 Random log text, real pattern", t3), ("T4 Match at index 0 (stops)", t4),
                     ("T5 Binary alphabet AAAA..B", t5)]:
    idx, c = brute(t, p)
    print(f"{name:34}{len(t):>7}{len(p):>5}{c:>13,}{len(t)-len(p)+1:>9,}{(len(t)-len(p)+1)*len(p):>11,}{c/len(t):>10.2f}")
    rows.append([name, len(t), len(p), c, idx])
# growth with pattern length m for the worst-case family
print("\nWorst-case family, n = 10000: comparisons vs m")
fam = []
for m in (5, 10, 20, 50, 100, 200):
    _, c = brute("A" * 10000, "A" * (m - 1) + "B"); fam.append((m, c)); print(f"m={m:>4}  comparisons={c:>10,}")
with open("../data/q3_raw.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["test", "n", "m", "comparisons", "match_index"]); w.writerows(rows)
    w.writerow([]); w.writerow(["worst_family_m", "comparisons"]); w.writerows(fam)
