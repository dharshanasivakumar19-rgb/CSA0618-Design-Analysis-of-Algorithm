"""Q6 - Exhaustive search for the helicopter payload problem (bitmask enumeration)"""
import random, time, csv, json
def exhaustive(items, cap):
    n = len(items); best_v = -1; best_mask = 0; feasible = 0; cands = 0
    for mask in range(1 << n):               # every bit pattern = one candidate subset
        cands += 1; w = v = 0
        for b in range(n):
            if mask >> b & 1: w += items[b][0]; v += items[b][1]
        if w <= cap:                         # feasibility check
            feasible += 1
            if v > best_v: best_v, best_mask = v, mask      # retain best
    return best_v, best_mask, cands, feasible
if __name__ == "__main__":
    # correctness instance - 5 packages, verified by hand
    small = [(3, 4), (4, 5), (2, 3), (5, 8), (1, 2)]; cap = 8   # (weight, value)
    bv, bm, c, f = exhaustive(small, cap)
    print("Small instance:", small, "capacity", cap)
    print(f"Best value={bv}, packages={[i+1 for i in range(5) if bm>>i&1]}, candidates={c}, feasible={f}")
    print("\nAll 32 subsets:")
    tab = []
    for mask in range(32):
        ids = [i+1 for i in range(5) if mask>>i&1]; w = sum(small[i-1][0] for i in ids); v = sum(small[i-1][1] for i in ids)
        tab.append([mask, ids, w, v, "Yes" if w <= cap else "No"])
        print(f"{mask:>3} {str(ids):18} W={w:>2} V={v:>2} feasible={'Yes' if w<=cap else 'No'}")
    json.dump(tab, open("../data/q6_small_table.json","w"))
    random.seed(8); rows = []
    print(f"\n{'n':>3}{'2^n':>12}{'Candidates':>12}{'Feasible':>10}{'Best value':>11}{'Time(s)':>10}")
    for n in (10, 12, 14, 16, 18, 20, 21):
        items = [(random.randint(5, 40), random.randint(10, 100)) for _ in range(n)]
        cap = sum(w for w, _ in items) // 2
        t = time.perf_counter(); bv, bm, c, f = exhaustive(items, cap); t = time.perf_counter() - t
        rows.append([n, 2**n, c, f, bv, round(t, 4)])
        print(f"{n:>3}{2**n:>12,}{c:>12,}{f:>10,}{bv:>11}{t:>10.3f}")
    with open("../data/q6_raw.csv","w",newline="") as fh:
        w = csv.writer(fh); w.writerow(["n","2^n","candidates","feasible","best_value","time_s"]); w.writerows(rows)
    tpc = rows[-1][5] / rows[-1][2]
    print(f"\nTime per candidate (n=21): {tpc*1e6:.2f} microseconds")
    for lim in (1, 5, 10, 30):
        import math; print(f"Response limit {lim:>2} s -> n_max ~ {int(math.log2(lim/tpc))}")
