"""Q2 - Sequential search on tool-issue records"""
import csv, time, random
def seq_search(records, tool):
    comp = 0
    for r in records:
        comp += 1
        if r[0] == tool: return r, comp
    return None, comp
def make(n):
    return [(f"T-{i:06d}", f"TECH-{i%97:03d}", f"{8+i%10}:{i%60:02d}", f"BAY-{i%12+1}") for i in range(n)]
rows = []
print(f"{'n':>9}{'Case':>18}{'Position':>10}{'Comparisons':>13}")
for n in (100, 1000, 10000, 100000):
    recs = make(n)
    cases = [("First", 0), ("Middle", n//2), ("Last", n-1)]
    for nm, p in cases:
        _, c = seq_search(recs, recs[p][0]); rows.append([n, nm, p+1, c]); print(f"{n:>9}{nm:>18}{p+1:>10}{c:>13}")
    _, c = seq_search(recs, "T-999999"); rows.append([n, "Unsuccessful", "-", c]); print(f"{n:>9}{'Unsuccessful':>18}{'-':>10}{c:>13}")
    random.seed(7); tot = 0
    for _ in range(1000):
        p = random.randrange(n); tot += seq_search(recs, recs[p][0])[1]
    rows.append([n, "Avg of 1000 random hits", "-", tot/1000]); print(f"{n:>9}{'Avg 1000 random':>18}{'-':>10}{tot/1000:>13.1f}")
with open("../data/q2_raw.csv","w",newline="") as f:
    w=csv.writer(f); w.writerow(["n","case","position","comparisons"]); w.writerows(rows)
# cost per comparison and boundary analysis
recs = make(100000); t=time.perf_counter()
for _ in range(20): seq_search(recs,"T-999999")
per_cmp = (time.perf_counter()-t)/(20*100000)
print(f"\nMeasured cost per comparison (Python): {per_cmp*1e9:.1f} ns")
sc = [("One hangar", 500, 200), ("20 facilities", 10000, 4000)]
print(f"\n{'Scenario':16}{'Active n':>9}{'Lookups/hr':>12}{'Avg cmp (hit)':>14}{'Cmp/hour':>14}{'Search time/lookup':>20}")
for nm,n,q in sc:
    avg=(n+1)/2; print(f"{nm:16}{n:>9}{q:>12}{avg:>14.0f}{avg*q:>14,.0f}{avg*per_cmp*1000:>17.3f} ms")
# hash-table alternative: dictionary
d = {r[0]: r for r in recs}; t=time.perf_counter()
for _ in range(100000): d.get("T-099999")
print(f"Dictionary lookup (n=100000): {(time.perf_counter()-t)/100000*1e9:.0f} ns/lookup, ~1 probe")
