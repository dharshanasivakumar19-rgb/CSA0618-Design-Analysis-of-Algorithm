"""Q4 - Brute-force closest pair of drones"""
import random, time, csv, math
def closest_pair(pts):
    n = len(pts); best = float("inf"); bp = None; pairs = dists = 0
    for i in range(n - 1):
        for j in range(i + 1, n):          # j > i : each unordered pair once
            pairs += 1; dists += 1
            dx = pts[i][0] - pts[j][0]; dy = pts[i][1] - pts[j][1]
            d = dx * dx + dy * dy          # squared distance, sqrt only at the end
            if d < best: best, bp = d, (i, j)
    return math.sqrt(best), bp, pairs, dists
random.seed(3)
rows = []
print(f"{'n':>7}{'n(n-1)/2':>14}{'Pairs examined':>16}{'Dist calcs':>13}{'Time(s)':>10}{'Closest dist':>14}")
for n in (10, 100, 500, 1000, 2000, 4000, 6000):
    pts = [(random.uniform(0, 10000), random.uniform(0, 10000)) for _ in range(n)]
    t = time.perf_counter(); d, bp, p, dc = closest_pair(pts); t = time.perf_counter() - t
    assert p == n * (n - 1) // 2
    rows.append([n, n*(n-1)//2, p, dc, round(t, 4), round(d, 3)])
    print(f"{n:>7,}{n*(n-1)//2:>14,}{p:>16,}{dc:>13,}{t:>10.4f}{d:>14.3f}")
with open("../data/q4_raw.csv", "w", newline="") as f:
    w = csv.writer(f); w.writerow(["n","theory_pairs","pairs_examined","distance_calcs","time_s","closest"]); w.writerows(rows)
# time per pair and extrapolation
tpp = rows[-1][4] / rows[-1][2]
print(f"\nTime per pair (n=6000): {tpp*1e9:.1f} ns")
for lim in (1, 5, 10):
    n = int((1 + math.sqrt(1 + 8 * lim / tpp)) / 2)
    print(f"Acceptable time {lim:>2} s  ->  n_max ~ {n:,}")
