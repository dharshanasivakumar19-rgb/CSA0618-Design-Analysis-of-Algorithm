"""Q7 - Redesign of Q6: depth-first search with feasibility pruning + optimistic-bound pruning"""
import random, time, csv, json
from q6_exhaustive import exhaustive
def redesigned(items, cap):
    # preprocessing: order by value/weight ratio so that the optimistic bound is tight
    order = sorted(range(len(items)), key=lambda i: -items[i][1] / items[i][0])
    W = [items[i][0] for i in order]; V = [items[i][1] for i in order]; n = len(items)
    best = [0, []]; nodes = [0]
    def bound(k, w, v):                     # fractional (relaxed) fill of remaining capacity
        room = cap - w; b = v
        for i in range(k, n):
            if W[i] <= room: room -= W[i]; b += V[i]
            else: b += V[i] * room / W[i]; break
        return b
    def dfs(k, w, v, chosen):
        nodes[0] += 1
        if v > best[0]: best[0] = v; best[1] = chosen[:]
        if k == n: return
        if bound(k, w, v) <= best[0]: return        # cannot beat incumbent -> prune whole subtree
        if w + W[k] <= cap:                           # include branch only if feasible
            chosen.append(order[k]); dfs(k + 1, w + W[k], v + V[k], chosen); chosen.pop()
        dfs(k + 1, w, v, chosen)                      # exclude branch
    dfs(0, 0, 0, [])
    return best[0], sorted(best[1]), nodes[0]
if __name__ == "__main__":
    small = [(3, 4), (4, 5), (2, 3), (5, 8), (1, 2)]
    print("Small instance check:", redesigned(small, 8), " (expected value 13, packages 3,4,5 -> indices 2,3,4)")
    random.seed(8); rows = []
    print(f"\n{'n':>3}{'Original cands':>16}{'Redesign nodes':>16}{'Reduction x':>13}{'Orig t(s)':>10}{'New t(s)':>10}{'Same optimum':>14}")
    for n in (10, 12, 14, 16, 18, 20, 21):
        items = [(random.randint(5, 40), random.randint(10, 100)) for _ in range(n)]
        cap = sum(w for w, _ in items) // 2
        t = time.perf_counter(); ov, _, oc, _ = exhaustive(items, cap); ot = time.perf_counter() - t
        t = time.perf_counter(); nv, _, nn = redesigned(items, cap); nt = time.perf_counter() - t
        rows.append([n, oc, nn, round(oc/nn, 1), round(ot, 4), round(nt, 5), ov == nv])
        print(f"{n:>3}{oc:>16,}{nn:>16,}{oc/nn:>13.1f}{ot:>10.3f}{nt:>10.5f}{str(ov==nv):>14}")
    # larger sizes: redesign only
    big = []; print(f"\nLarger instances (redesign only; exhaustive would need 2^n candidates)")
    print(f"{'n':>4}{'2^n':>18}{'Nodes visited':>15}{'Time(s)':>10}")
    for n in (25, 30, 40, 50, 60):
        items = [(random.randint(5, 40), random.randint(10, 100)) for _ in range(n)]
        cap = sum(w for w, _ in items) // 2
        t = time.perf_counter(); nv, _, nn = redesigned(items, cap); nt = time.perf_counter() - t
        big.append([n, 2**n, nn, round(nt, 4)]); print(f"{n:>4}{2**n:>24,}{nn:>15,}{nt:>10.4f}")
    # adversarial: value == weight (equal ratios), even weights, ODD capacity -> bound = capacity can never be reached
    adv = []; print(f"\nAdversarial (value == weight, even weights, odd capacity: bound never tight):")
    print(f"{'n':>4}{'2^n':>12}{'Nodes visited':>15}{'Reduction':>11}{'Time(s)':>10}")
    for n in (14, 16, 18, 20, 22, 24):
        ws = [random.randint(10, 30) * 2 for _ in range(n)]
        items = [(w, w) for w in ws]; cap = sum(ws) // 2 | 1
        t = time.perf_counter(); nv, _, nn = redesigned(items, cap); nt = time.perf_counter() - t
        adv.append([n, 2**n, nn, round(nt, 3)]); print(f"{n:>4}{2**n:>12,}{nn:>15,}{2**n/nn:>11.1f}{nt:>10.3f}")
    with open("../data/q7_raw.csv","w",newline="") as f:
        w = csv.writer(f); w.writerow(["n","orig_candidates","redesign_nodes","reduction","orig_time_s","new_time_s","same_optimum"]); w.writerows(rows)
        w.writerow([]); w.writerow(["n","2^n","nodes","time_s"]); w.writerows(big)
        w.writerow([]); w.writerow(["adv_n","2^n","nodes"]); w.writerows(adv)
    json.dump({"rows":rows,"big":big,"adv":adv}, open("../data/q7.json","w"))
